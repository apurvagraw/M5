package com.cg.pagefactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Module2PF {

	
	WebDriver driver;
	@Test (dataProvider="LoginData")
	public void LoginToShoppingApp(String username, String password)throws InterruptedException
	
	{
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		driver.findElement(By.id("input-email")).sendKeys(username);
		driver.findElement(By.id("input-password")).sendKeys(password);
		driver.findElement(By.xpath("html/body/div[2]/div/div/div/div[2]/div/form/input")).click();;
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
		driver.close();

	}
	
	@DataProvider(name="LoginData")
	public Object[][]datapass()
	{
		Object[][]data=new Object[3][2];
		data[0][0]="group1";
		data[0][1]="12345";
		data[1][0]="SeleniumUser";
		data[1][1]="selenium123";
		data[2][0]="Ayush";
		data[2][1]="Capgemini";
		
		return data;
	}
	
}
